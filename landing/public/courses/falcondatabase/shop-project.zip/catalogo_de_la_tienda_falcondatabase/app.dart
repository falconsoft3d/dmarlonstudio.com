// Shop catalogue: categories, products and reviews read from FalconDatabase
// with lib/db.dart (App → Database). The anon key only reads: the shop
// tables are public_read.
import 'package:flutter/material.dart';

import 'db.dart';

class App extends ChangeNotifier {
  List<Map<String, dynamic>> categories = [];
  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> reviews = [];
  String search = '';
  Object? category;
  bool loading = false;
  String error = '';

  Future<void> start() async {
    try {
      categories = await db.table('categories').list(order: 'name');
    } on DbError catch (e) {
      error = e.message;
    }
    await load();
  }

  /// The products of the chosen category whose name contains the search:
  /// GET /tables/products?category_id=eq.2&name=ilike.%tea%&order=name
  Future<void> load() async {
    loading = true;
    notifyListeners();
    final text = search.trim();
    try {
      products = await db.table('products').list(
        where: {
          if (category != null) 'category_id': category,
          if (text.isNotEmpty) 'name': 'ilike.%$text%',
        },
        order: 'name',
      );
      error = '';
    } on DbError catch (e) {
      error = e.message;
    }
    loading = false;
    notifyListeners();
  }

  void pick(Map<String, dynamic>? c) {
    category = c?['id'];
    load();
  }

  /// The reviews of a product (a second query: the REST API has no joins).
  Future<void> open(Map<String, dynamic> p) async {
    reviews = [];
    notifyListeners();
    try {
      reviews = await db.table('reviews').list(where: {'product_id': p['id']}, order: 'id');
    } on DbError catch (e) {
      error = e.message;
    }
    notifyListeners();
  }

  // ------------------------------------------------------------ to show
  Object? categoryId(Map<String, dynamic> p) => p['category_id'];

  String categoryName(Object? id) =>
      '${categories.where((c) => c['id'] == id).firstOrNull?['name'] ?? ''}';

  String get filter => categoryName(category);

  String price(Map<String, dynamic> p) => '${(p['price'] as num).toStringAsFixed(2)} €';

  bool soldOut(Map<String, dynamic> p) => (p['stock'] as num? ?? 0) <= 0;

  String tags(Map<String, dynamic> p) =>
      [for (final t in (p['tags'] as List?) ?? const []) '#$t'].join('  ');

  String stars(Map<String, dynamic> r) {
    final n = (r['rating'] as num? ?? 0).toInt().clamp(0, 5);
    return '★' * n + '☆' * (5 - n);
  }

  String get rating => reviews.isEmpty
      ? '—'
      : '${(reviews.fold<num>(0, (s, r) => s + (r['rating'] as num)) / reviews.length).toStringAsFixed(1)} ★ (${reviews.length})';

  static const _icons = {1: Icons.bakery_dining, 2: Icons.local_cafe, 3: Icons.icecream, 4: Icons.eco};
  static const _colors = {1: Color(0xFF8D6E63), 2: Color(0xFF5C6BC0), 3: Color(0xFF26A69A), 4: Color(0xFF7CB342)};

  IconData icon(Object? category) => _icons[category] ?? Icons.shopping_basket;

  Color color(Object? category) => _colors[category] ?? const Color(0xFF78909C);
}
