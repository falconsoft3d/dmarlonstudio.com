// Shop catalogue: categories, products and reviews read from Cloud Firestore
// with lib/db.dart (App → Database). Firestore filters by category; the
// search runs here, because Firestore cannot search inside a text.
import 'package:flutter/material.dart';

import 'db.dart';

class App extends ChangeNotifier {
  List<Map<String, dynamic>> categories = [];
  List<Map<String, dynamic>> all = [];
  List<Map<String, dynamic>> reviews = [];
  String search = '';
  Object? category;
  bool loading = false;
  String error = '';

  Future<void> start() async {
    try {
      categories = await db.table('categories').list();
      categories.sort((a, b) => '${a['name']}'.compareTo('${b['name']}'));
    } on DbError catch (e) {
      error = e.message;
    }
    await load();
  }

  /// The products of the chosen category (a structured query with where).
  Future<void> load() async {
    loading = true;
    notifyListeners();
    try {
      all = await db.table('products').list(
        where: {if (category != null) 'category': category},
      );
      all.sort((a, b) => '${a['name']}'.compareTo('${b['name']}'));
      error = '';
    } on DbError catch (e) {
      error = e.message;
    }
    loading = false;
    notifyListeners();
  }

  /// What the list shows: the products whose name contains the search.
  List<Map<String, dynamic>> get products {
    final text = search.trim().toLowerCase();
    return [
      for (final p in all)
        if ('${p['name']}'.toLowerCase().contains(text)) p,
    ];
  }

  void pick(Map<String, dynamic>? c) {
    category = c?['id'];
    load();
  }

  /// The reviews of a product: the documents of reviews whose product is
  /// its id.
  Future<void> open(Map<String, dynamic> p) async {
    reviews = [];
    notifyListeners();
    try {
      reviews = await db.table('reviews').list(where: {'product': p['id']});
    } on DbError catch (e) {
      error = e.message;
    }
    notifyListeners();
  }

  // ------------------------------------------------------------ to show
  Object? categoryId(Map<String, dynamic> p) => p['category'];

  String categoryName(Object? id) =>
      '${categories.where((c) => c['id'] == id).firstOrNull?['name'] ?? ''}';

  String get filter => categoryName(category);

  String price(Map<String, dynamic> p) => '${(p['price'] as num).toStringAsFixed(2)} €';

  bool soldOut(Map<String, dynamic> p) => (p['stock'] as num? ?? 0) <= 0;

  String tags(Map<String, dynamic> p) =>
      [for (final t in (p['tags'] as List?) ?? const []) '#$t'].join('  ');

  String stars(Map<String, dynamic> r) {
    final n = (r['rating'] as num? ?? 0).toInt().clamp(0, 5);
    return '★' * n + '☆' * (5 - n);
  }

  String get rating => reviews.isEmpty
      ? '—'
      : '${(reviews.fold<num>(0, (s, r) => s + (r['rating'] as num)) / reviews.length).toStringAsFixed(1)} ★ (${reviews.length})';

  static const _icons = {'cat1': Icons.bakery_dining, 'cat2': Icons.local_cafe, 'cat3': Icons.icecream, 'cat4': Icons.eco};
  static const _colors = {'cat1': Color(0xFF8D6E63), 'cat2': Color(0xFF5C6BC0), 'cat3': Color(0xFF26A69A), 'cat4': Color(0xFF7CB342)};

  IconData icon(Object? category) => _icons[category] ?? Icons.shopping_basket;

  Color color(Object? category) => _colors[category] ?? const Color(0xFF78909C);
}
