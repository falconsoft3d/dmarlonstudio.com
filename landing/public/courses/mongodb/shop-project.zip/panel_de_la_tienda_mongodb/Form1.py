import re

# Shop dashboard (MongoDB). The three tables load the query of their
# "Query" property from the Shop connection; this code runs the search and
# fills the four figures and the chart.
SUMMARY = {"collection": "orders", "aggregate": [
    {"$match": {"status": {"$ne": "cancelled"}}},
    {"$group": {"_id": None, "orders": {"$sum": 1}, "sales": {"$sum": "$total"},
                "average": {"$avg": "$total"}, "customers": {"$addToSet": "$customer_id"}}},
    {"$project": {"_id": 0, "orders": 1, "sales": 1, "average": 1,
                  "customers": {"$size": "$customers"}}},
]}

BY_CATEGORY = {"collection": "orders", "aggregate": [
    {"$match": {"status": {"$ne": "cancelled"}}},
    {"$unwind": "$items"},
    {"$lookup": {"from": "products", "localField": "items.product_id",
                 "foreignField": "_id", "as": "product"}},
    {"$lookup": {"from": "categories", "localField": "product.category_id",
                 "foreignField": "_id", "as": "category"}},
    {"$group": {"_id": {"$arrayElemAt": ["$category.name", 0]},
                "sales": {"$sum": {"$multiply": ["$items.qty", "$items.price"]}}}},
    {"$sort": {"_id": 1}},
    {"$project": {"_id": 0, "category": "$_id", "sales": 1}},
]}


def money(value):
    return "%.2f €" % float(value or 0)


class Form1(FormDesign):
    def form_create(self):
        self.search()
        self.summary()

    def BtnSearch_click(self):
        self.search()

    def Search_return(self, event=None):
        self.search()

    def search(self):
        # The "?" of the query takes the text (escaped: it is a regex).
        text = re.escape(self.Search.get().strip())
        self.Products_refresh((text,))

    def summary(self):
        try:
            row = self.Shop.query(SUMMARY)[0]
            sales = self.Shop.query(BY_CATEGORY)
        except DataError as error:
            tkinter.messagebox.showerror(self.root.title(), str(error))
            return
        self.KpiOrders.config(text=str(row["orders"]))
        self.KpiSales.config(text=money(row["sales"]))
        self.KpiAverage.config(text=money(row["average"]))
        self.KpiCustomers.config(text=str(row["customers"]))
        self.SalesChart.set_series(
            "sales",
            [float(r["sales"]) for r in sales],
            x=[r["category"] for r in sales],
        )
