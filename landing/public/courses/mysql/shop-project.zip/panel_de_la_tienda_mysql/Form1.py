# Shop dashboard (MySQL). The three tables load the query of their
# "Query" property from the Shop connection; this code runs the search and
# fills the four figures and the chart.
SUMMARY = """
SELECT COUNT(*) AS orders, SUM(total) AS sales, AVG(total) AS average,
       COUNT(DISTINCT customer_id) AS customers
FROM orders
WHERE status <> 'cancelled'
"""

BY_CATEGORY = """
SELECT c.name AS category, SUM(i.qty * i.price) AS sales
FROM order_items i
JOIN orders o ON o.id = i.order_id
JOIN products p ON p.id = i.product_id
JOIN categories c ON c.id = p.category_id
WHERE o.status <> 'cancelled'
GROUP BY c.name
ORDER BY c.name
"""


def money(value):
    return "%.2f €" % float(value or 0)


class Form1(FormDesign):
    def form_create(self):
        self.search()
        self.summary()

    def BtnSearch_click(self):
        self.search()

    def Search_return(self, event=None):
        self.search()

    def search(self):
        # The ? of the query takes the text: never joined into the SQL.
        text = "%" + self.Search.get().strip() + "%"
        self.Products_refresh((text,))

    def summary(self):
        try:
            row = self.Shop.query(SUMMARY)[0]
            sales = self.Shop.query(BY_CATEGORY)
        except DataError as error:
            tkinter.messagebox.showerror(self.root.title(), str(error))
            return
        self.KpiOrders.config(text=str(row["orders"]))
        self.KpiSales.config(text=money(row["sales"]))
        self.KpiAverage.config(text=money(row["average"]))
        self.KpiCustomers.config(text=str(row["customers"]))
        self.SalesChart.set_series(
            "sales",
            [float(r["sales"]) for r in sales],
            x=[r["category"] for r in sales],
        )
